using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Tourism
{
    // === Моделі ===
    public class BookingViewModel
    {
        public Guid BookingId { get; set; }
        public string TravelerName { get; set; }
        public string TourTitle { get; set; }
        public decimal TotalPrice { get; set; }
    }

    // === Інтерфейси ===
    public interface IBookingRepository
    {
        Guid Create(string email, Guid scheduleId, Guid? roomTypeId);
        void Confirm(Guid bookingId);
        IEnumerable<BookingViewModel> GetAllBookings();
    }

    public interface IUnitOfWork : IDisposable
    {
        IBookingRepository Bookings { get; }
        void Commit();
        void Rollback();
    }

    // === Реалізація ===
    public class BookingRepository : IBookingRepository
    {
        private readonly SqlTransaction _transaction;
        private readonly SqlConnection _connection;
        public BookingRepository(SqlTransaction transaction)
        {
            _transaction = transaction;
            _connection = transaction.Connection;
        }
         public Guid Create(string email, Guid scheduleId, Guid? roomTypeId)
        {
            using (var cmd = new SqlCommand("usp_CreateNewBooking", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TravelerEmail", email);
                cmd.Parameters.AddWithValue("@ScheduleID", scheduleId);
                cmd.Parameters.AddWithValue("@RoomTypeID", (object)roomTypeId ?? DBNull.Value);
                var outputParam = cmd.Parameters.Add("@NewBookingID", SqlDbType.UniqueIdentifier);
                outputParam.Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                return (Guid)outputParam.Value;
            }
        }

        public void Confirm(Guid bookingId)
        {
            using (var cmd = new SqlCommand("usp_ConfirmBooking", _connection, _transaction))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookingID", bookingId);
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<BookingViewModel> GetAllBookings()
        {
            var list = new List<BookingViewModel>();
            string sql = "SELECT BookingID, TravelerName, TourTitle, total_price FROM v_AllBookings";
            using (var cmd = new SqlCommand(sql, _connection, _transaction))
            {
                cmd.CommandType = CommandType.Text;
                using (var reader = cmd.ExecuteReader())
                    while (reader.Read())
                        list.Add(new BookingViewModel
                        {
                            BookingId = reader.GetGuid(0),
                            TravelerName = reader.GetString(1),
                            TourTitle = reader.GetString(2),
                            TotalPrice = reader.GetDecimal(3)
                        });
            }
            return list;
        }
    }

    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlConnection _connection;
        private SqlTransaction _transaction;
        private IBookingRepository _bookingRepository;
        private bool _disposed;
        public UnitOfWork(string connectionString)
        {
            _connection = new SqlConnection(connectionString);
            _connection.Open();
            _transaction = _connection.BeginTransaction();
        }

        public IBookingRepository Bookings
        {
            get { return _bookingRepository ??= new BookingRepository(_transaction); }
        }

        public void Commit()
        {
            try { _transaction.Commit(); }
            catch { _transaction.Rollback(); throw; }
        }

        public void Rollback() { _transaction.Rollback(); }

        public void Dispose()
        {
            if (!_disposed)
            {
                _transaction?.Dispose();
                _connection?.Dispose();
                _disposed = true;
            }
        }
    }

    // === Main ===
    class Program
    {
        static void Main(string[] args)
        {
            // підключення до БД
            //const string connectionString = "Server=DESKTOP-EMI94R6;Database=Tourism;Trusted_Connection=True;TrustServerCertificate=True;";
            const string connectionString = "Server=.;Database=Tourism;Trusted_Connection=True;TrustServerCertificate=True;";

            Console.WriteLine("Підключення до БД...\n");
            Console.WriteLine("Перед створенням нового бронювання:");
            using (var uowRead = new UnitOfWork(connectionString))
            {
                Console.WriteLine("Читання даних через View (v_AllBookings):");
                var bookings = uowRead.Bookings.GetAllBookings();
                int count = 0;
                foreach (var b in bookings)
                {
                    count++;
                    Console.WriteLine($"   [{count}] {b.TourTitle} | Клієнт: {b.TravelerName} | {b.TotalPrice} UAH");
                }
                if (count == 0)
                    Console.WriteLine("(Список порожній. Перевірте, чи є бронювання зі статусом 'Confirmed')");
            }

            using (var uow = new UnitOfWork(connectionString))
            {
                try
                {
                    Guid realScheduleId = Guid.Parse("7ec6ecaa-a51f-40c0-b6ea-7b83f3741519");

                    // деяка існуюча електрона пошта із таблиці Traveler
                    string travelerEmail = "traveler2@email.com";
                    Console.WriteLine("\n1. Створення бронювання...");
                    Guid newBookingId = uow.Bookings.Create(travelerEmail, realScheduleId, null);
                    Console.WriteLine($"   -> Бронювання ID: {newBookingId} створено (Pending).");
                    Console.Write("Бажаєте відразу підтвердити бронювання? (Y/N): ");
                    string input = Console.ReadLine()?.ToUpper();
                    if (input == "Y")
                    {
                        Console.WriteLine("2. Підтвердження бронювання...");
                        uow.Bookings.Confirm(newBookingId);
                        Console.WriteLine("   -> Статус змінено на 'Confirmed'.");
                    }
                    else
                        Console.WriteLine("   -> Бронювання залишається у статусі 'Pending'.");
                    // коміт, щоб записати дані у БД
                    uow.Commit();
                    Console.WriteLine("   -> Успішно! Бронювання створено (Pending).");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   -> Помилка: {ex.Message}");
                    uow.Rollback();
                }
            }

            Console.WriteLine("\nПісля створення нового бронювання:");
            using (var uowRead = new UnitOfWork(connectionString))
            {
                Console.WriteLine("\nЧитання даних через View (v_AllBookings):");
                var bookings = uowRead.Bookings.GetAllBookings();
                int count = 0;
                foreach (var b in bookings)
                {
                    count++;
                    Console.WriteLine($"   [{count}] {b.TourTitle} | Клієнт: {b.TravelerName} | {b.TotalPrice}");
                }
                if (count == 0)
                    Console.WriteLine("(Список порожній. Перевірте, чи є бронювання зі статусом 'Confirmed')");
            }
        }
    }
}